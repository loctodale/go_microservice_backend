Module example.com/first is used to test the first tag for a major version.
